<p align="center"> 
<a href="https://github.com/GataNina-Li"><img src="http://readme-typing-svg.herokuapp.com?font=mono&size=17&duration=4000&color=9e62d7&center=falso&vCenter=falso&lines=GataBot-MD++%F0%9F%90%88;Gracias+por+visitar+este+repositorio.+%F0%9F%92%96" height="90px"></a> 
<img src="https://qu.ax/lHrxl.jpeg" alt="GataBot-MD" style="width: 100%; height: auto; max-width: 500px;">
  
> Este proyecto es de código abierto, para más información visita la **[Política de GataBot. 😼](https://github.com/GataNina-Li/GataBot-MD/blob/master/terms.md)** 
</p>

<p align="center">
<a href="#"><img title="GataBot-MD" src="https://img.shields.io/badge/SI TE AGRADA EL REPOSITORIO APOYAME CON UNA 🌟 ¡GRACIAS! -red?colorA=%255ff0000&colorB=%23017e40&style=for-the-badge"></a> 
<img src="https://i.pinimg.com/originals/d4/3c/90/d43c902873d4db8c85974dfd0798030b.gif" height="28px">
</p>  

<p align="center">
<a href="#"><img title="GataBot-MD" src="https://img.shields.io/badge/LEA TODO EL README-red?colorA=%F77F48FF&colorB=%F77F48FF&style=for-the-badge"></a> 
<a href="#"><img title="GataBot-MD" src="https://img.shields.io/badge/COMPATIBLE CON LA VERSIÓN MULTI DISPOSITIVOS DE WHATSAPP-red?colorA=%F77F48FF&colorB=%F77F48FF&style=for-the-badge"></a>
</p>

<p align="center">   
<a href="https://github.com/GataNina-Li/GataBot-MD/watchers"><img title="Watchers" src="https://img.shields.io/github/watchers/GataNina-Li/GataBot-MD?label=Watchers&color=green&style=flat-square"></a>
<a href="https://github.com/GataNina-Li/GataBot-MD/stargazers"><img title="Stars" src="https://img.shields.io/github/stars/GataNina-Li/GataBot-MD?label=Stars&color=yellow&style=flat-square"></a>
</p>

<div align="center">
 
[![Gmail](https://img.shields.io/badge/Gmail-D14836?style=for-the-badge&logo=gmail&logoColor=white)](mailto:centergatabot@gmail.com)
[![Support](https://img.shields.io/badge/Support-2CA5E0?style=for-the-badge&logo=telegram&logoColor=white)](https://t.me/SoporteGataBot)
[![WhatsApp](https://img.shields.io/badge/STAFF-25D366?style=for-the-badge&logo=whatsapp&logoColor=white)](https://wa.me/message/C45GXBEFTPONE1)
[![Facebook](https://img.shields.io/badge/Facebook-1877F2?style=for-the-badge&logo=facebook&logoColor=white)](https://facebook.com/groups/872989990425789/)
[![YouTube](https://img.shields.io/badge/YouTube-FF0000?style=for-the-badge&logo=youtube&logoColor=white)](https://www.youtube.com/@gatadios)
[![Instagram](https://img.shields.io/badge/Instagram-E4405F?style=for-the-badge&logo=instagram&logoColor=white)](https://instagram.com/gata_dios)
[![PayPal](https://img.shields.io/badge/PayPal-00457C?style=for-the-badge&logo=paypal&logoColor=white)](https://paypal.me/OficialGD)
</div>

### 👇 `Todas las cuentas están aquí!!`
[![Enlaces](https://img.shields.io/badge/GataBot_Accounts-000000%7D?style=for-the-badge&logo=biolink&logoColor=white)](https://www.atom.bio/gatabot/)

### 🆕 Hemos resumido las principales características de este proyecto. ¡Revisa el resumen!
<details>
  <summary><b>⭐ RESUMEN</b></summary>

 <details>
  <summary><b>🐈 SOBRE GATABOT</b></summary>
  
| TEMA | DESCRIPCIÓN | ATAJO |
|------|-------------|-------|
| 🔑 **Owners** | *Define quiénes tendrán control total del bot.* | [![Here](https://img.shields.io/badge/Aquí-green)](https://github.com/GataNina-Li/GataBot-MD/blob/c74265fe42d465b52d64209a50b02a5af437b8b2/config.js#L15) |
| ✏️ **Modificar nombre** | *Modifica el nombre del bot de manera sencilla.* | [![Here](https://img.shields.io/badge/Aquí-green)](https://github.com/GataNina-Li/GataBot-MD/blob/c74265fe42d465b52d64209a50b02a5af437b8b2/config.js#L144) |
| 🌐 **Idioma** | *Configura el idioma predeterminado para el bot.* | [![Here](https://img.shields.io/badge/Aquí-green)](https://github.com/GataNina-Li/GataBot-MD/blob/c74265fe42d465b52d64209a50b02a5af437b8b2/config.js#L56) |
| ❇️ **Idiomas disponibles** | *Conoce a los implicados que hacen posible este proyecto.* | [![Here](https://img.shields.io/badge/Aquí-green)](https://github.com/GataNina-Li/GataBot-MD/tree/master#-idiomas-disponibles-para-gatabot) |
| 📲 **Conectar con código (opcional)** | *Vincula directamente tu número para recibir código de 8 dígitos.* | [![Here](https://img.shields.io/badge/Aquí-green)](https://github.com/GataNina-Li/GataBot-MD/blob/c74265fe42d465b52d64209a50b02a5af437b8b2/config.js#L44) |
| 🆙 **Nivel de usuarios** | *Ajusta la dificultad para que los usuarios suban de nivel en el bot.* | [![Here](https://img.shields.io/badge/Aquí-green)](https://github.com/GataNina-Li/GataBot-MD/blob/c74265fe42d465b52d64209a50b02a5af437b8b2/config.js#L220) |
| 😎 **Clonar proyecto** | *Crea tu propia versión usando como base este proyecto.* | [![Here](https://img.shields.io/badge/Aquí-green)](https://github.com/GataNina-Li/GataBot-MD/fork) |
| 🐈 **Política** | *Descubre el compromiso y la dedicación detrás de este proyecto.* | [![Here](https://img.shields.io/badge/Aquí-green)](https://github.com/GataNina-Li/GataBot-MD/blob/master/terms.md) |
| 👥 **Distribuidores autorizados** | *Usuarios con licencia oficial para distribuir GataBot.* | [![Here](https://img.shields.io/badge/Aquí-green)](https://github.com/GataNina-Li/GataBot-MD#distribuidores-autorizados-o-resellers---preguntas) |
| ✅ **Colaboradores** | *Conoce a los implicados que hacen posible este proyecto.* | [![Here](https://img.shields.io/badge/Aquí-green)](https://github.com/GataNina-Li/GataBot-MD/graphs/contributors) |
</details>  
<details>
  <summary><b>🫶 PATROCINADORES</b></summary>

| TEMA | DESCRIPCIÓN | ATAJO |
|------|-------------|-------|
| ☁️ **SKY ULTRA PLUS** | *Activar en SkyUltraPlus* | [![Here](https://img.shields.io/badge/Aquí-blue)](https://github.com/GataNina-Li/GataBot-MD/tree/master#%EF%B8%8F-sky-ultra-plus) |
| 📦⛏️ **BOXMINE HOST** | *Activar en BoxMine Host* | [![Here](https://img.shields.io/badge/Aquí-blue)](https://github.com/GataNina-Li/GataBot-MD#%EF%B8%8F-boxmine-host) |
| 🎇 **HOSTING-PY** | *Activar en Hosting-Py* | [![Here](https://img.shields.io/badge/Aquí-blue)](https://github.com/GataNina-Li/GataBot-MD#-hosting-py) |
| **TK HOST** | *Activar en TK Host* | [![Here](https://img.shields.io/badge/Aquí-blue)](https://github.com/GataNina-Li/GataBot-MD#tk-host) |
</details>

 <details>
  <summary><b>🪄 INSTALACIÓN POR TERMUX</b></summary>
  
| TEMA | DESCRIPCIÓN | ATAJO |
|------|-------------|-------|
| 🪄 **Instalación automática** | *Sigue estos pasos para instalar el bot automáticamente.* | [![Here](https://img.shields.io/badge/Ver_instrucciones-black)](https://github.com/GataNina-Li/GataBot-MD/tree/master?tab=readme-ov-file#-opci%C3%B3n-1-instalaci%C3%B3n-autom%C3%A1tica-) |
| 🪄 **Instalación manual** | *Instala GataBot manualmente siguiendo esta guía.* | [![Here](https://img.shields.io/badge/Ver_instrucciones-black)](https://github.com/GataNina-Li/GataBot-MD/#-opción-2-instalación-manual-por-termux---github) |
| 🪄 **Instalación por archivos locales** | *Usa archivos locales para instalar GataBot en Termux.* | [![Here](https://img.shields.io/badge/Ver_instrucciones-black)](https://github.com/GataNina-Li/GataBot-MD/#-opción-3-instalación-por-termux---archivos) |
| 🪄 **Ejecución 24/7** | *Comandos para mantener GataBot ejecutándose continuamente.* | [![Here](https://img.shields.io/badge/Ver_comandos-black)](https://github.com/GataNina-Li/GataBot-MD/#-usar-gatabot-247-en-termux) |
| 🪄 **Actualización** | *Sigue estos comandos para actualizar GataBot a la última versión.* | [![Here](https://img.shields.io/badge/Ver_instrucciones-black)](https://github.com/GataNina-Li/GataBot-MD/#-actualizar-gatabot) |
</details>  
<details>
  <summary><b>🚄 DESPLIEGUE</b></summary>

| TEMA | DESCRIPCIÓN | ATAJO |
|------|-------------|-------|
| ⚡ **Replit** | *Instalación directa por Replit* | [![Here](https://img.shields.io/badge/Aquí-orange)](https://github.com/GataNina-Li/GataBot-MD#-despliegue) |
| ⏏️ **Koyeb** | *Instalación directa por Koyeb* | [![Here](https://img.shields.io/badge/Aquí-blue)](https://github.com/GataNina-Li/GataBot-MD#-despliegue) |
| 💻 **Windows** | *Instalar para Windows 10 o superior* | [![Here](https://img.shields.io/badge/Aquí-pink)](https://github.com/GataNina-Li/GataBot-MD#-despliegue) |
</details>
</details>

----

### 🌟 (OPCIÓN 1) INSTALACIÓN AUTOMÁTICA 🫰
<details>
  <summary><b>Toca para ver más.</b></summary>
 
[![blog](https://img.shields.io/badge/Instalacion-Automatica-FF0000?style=for-the-badge&logo=youtube&logoColor=white)](https://youtube.com/shorts/PESW8LXXlOI?feature=share)
> *Comandos para instalar de forma automática en Termux*
```bash
termux-setup-storage
```
```bash
apt update -y && yes | apt upgrade && pkg install -y bash wget mpv && wget -O - https://raw.githubusercontent.com/GataNina-Li/GataBot-MD/master/gata.sh | bash
```
### Edita lo siguiente si deseas usar este método de instalación en tú repositorio previamente hecho un fork
```js
// PERSONALIZAR INSTALACIÓN AUTOMÁTICA (En caso de una Bifurcación)
// Parámetros editables

// REFERENCIA
"wget -O - https://raw.githubusercontent.com/GataNina-Li/GataBot-MD/master/gata.sh | bash"

// PARÁMETROS QUE PUEDE SER MODIFICADOS --> "[...]"
// Reemplace por su usuario de GitHub, y nombre del repositorio
"wget -O - https://raw.githubusercontent.com/[usuario]/[repositorio]/master/gata.sh | bash"
```
#### MODIFICAR ARCHIVO [`gata.sh`](https://github.com/GataNina-Li/GataBot-MD/blob/master/gata.sh)
```js
//LÍNEAS A MODIFICAR
205 --> "git clone https://github.com/[user]/[repositorio].git"
//Ejemplo: git clone https://github.com/GataNina-Li/GataBot-MD.git

209 --> "cd [repositorio]"
//Ejemplo: cd GataBot-MD

//Una vez hecho estos cambios ejecute los nuevos comandos en Termux
```
</details>

-----
### 🪄 (OPCIÓN 2) INSTALACIÓN MANUAL POR TERMUX - GITHUB 
<details>
  <summary><b>Toca para ver más.</b></summary>
 
> *Comandos para instalar de forma manual*
```bash
termux-setup-storage
```
```bash
apt update && apt upgrade && pkg install -y git nodejs ffmpeg imagemagick yarn
```
```bash
git clone https://github.com/GataNina-Li/GataBot-MD && cd GataBot-MD
```
```bash
yarn install && npm install
```
```bash
npm start
```
> *Si aparece **(Y/I/N/O/D/Z) [default=N] ?** use la letra **"y" + "ENTER"** para continuar con la instalación*
</details>

----
### 📁 (OPCIÓN 3) INSTALACIÓN POR TERMUX - ARCHIVOS
<details>
  <summary><b>Toca para ver más.</b></summary>
 
> *Descarga y Descomprime*
### [`GataBot-MD ~ Archivos`](https://github.com/GataNina-Li/GataBot-MD/archive/refs/heads/master.zip)
[![blog](https://img.shields.io/badge/Termux-GataBotMD-FF0000?style=for-the-badge&logo=youtube&logoColor=white)
](https://youtu.be/UcWlyQ8u5HE)
```bash
termux-setup-storage
```
```bash
apt update && apt upgrade && pkg install -y git nodejs ffmpeg imagemagick yarn
```
```bash
cd storage/downloads/GataBot-MD-master/GataBot-MD-master 
```
```bash
yarn install
```
```bash
npm install
```
```bash
npm start
```
* #### APLICACIÓN RECOMENDADA PARA [`DESCOMPRIMIR`](https://play.google.com/store/apps/details?id=com.rarlab.rar)
* #### APLICACIÓN RECOMENDADA PARA EDITAR [`NÚMERO DE OWNER`](https://play.google.com/store/apps/details?id=com.rhmsoft.code)
> *Guardar los archivos en la ubicación: `storage/downloads/GataBot-MD-master/GataBot-MD-master`*
</details>

----
### 🚀 USAR GATABOT 24/7 EN TERMUX 
<details>
  <summary><b>Toca para ver más.</b></summary>
 
> *Ejecutar estos comandos dentro de la carpeta GataBot-MD*
```bash
termux-wake-lock && npm i -g pm2 && pm2 start index.js && pm2 save && pm2 logs 
``` 
#### ⬇️ Opciones Disponibles
> *Esto eliminará todo el historial que hayas establecido con PM2:*
```bash 
pm2 delete index
``` 
> *Si tienes cerrado Termux y quiere ver de nuevo la ejecución use:*
```bash 
pm2 logs 
``` 
> *Si desea detener la ejecución de Termux use:*
```bash 
pm2 stop index
``` 
> *Si desea iniciar de nuevo la ejecución de Termux use:*
```bash 
pm2 start index
```
---- 
### 👉 ACTIVAR EN CASO DE DETENERSE EN TERMUX
> _Si despues que ya instalastes tu bot y termux te salta en blanco, se fue tu internet o reiniciaste tu celular, solo realizaras estos pasos:_
```bash
cd && cd GataBot-MD && npm start
```
----
### ✳️ OBTENER OTRO CODIGO QR EN TERMUX
> *Detén el bot, haz click en el símbolo (ctrl) [default=z] usar la letra "z" + "ENTER" hasta que salga algo verdes similar a: `GataBot-MD $`*
> **Escribe los siguientes comando uno x uno :**
```bash 
cd && cd GataBot-MD && rm -rf GataBotSession && npm run qr
```
----
### ✳️ OBTENER NUEVO CÓDIGO DE 8 DÍGITOS 
```bash 
cd && cd GataBot-MD && rm -rf GataBotSession && npm run code
```
</details>

----
### 😼 ACTUALIZAR GATABOT
<details>
  <summary><b>Toca para ver más.</b></summary>
  
> *Comandos para actualizar GataBot-MD de forma automática*
```bash
grep -q 'bash\|wget' <(dpkg -l) || apt install -y bash wget && wget -O - https://raw.githubusercontent.com/GataNina-Li/GataBot-MD/master/update.sh | bash 
```
#### Para que no pierda su progreso en GataBot, estos comandos realizarán un respaldo de su `database.json` y se agregará a la versión más reciente.
> *Estos comandos solo funcionan para TERMUX, REPLIT, LINUX*
</details>

-----
### ☁️ SKY ULTRA PLUS 
[![YouTube](https://img.shields.io/badge/SkyUltraPlus-Host-FF0000?style=for-the-badge&logo=youtube&logoColor=white)](https://youtu.be/fZbcCLpSH6Y?si=1sDen7Bzmb7jVpAI)

<a href="https://skyultraplus.com"><img src="https://qu.ax/wbJoB.png" height="125px"></a>

### Información sobre Sky
- **Pagina Oficial:** [`Aqui`](https://skyultraplus.com)
- **Dashboard:** [`Aquí`](https://dash.skyultraplus.com)
- **Panel:** [`Aquí`](https://panel.skyultraplus.com)
- **Estado de servicios:** [`Aquí`](https://estado.skyultraplus.com)
- **Canal de WhatsApp:** [`Aquí`](https://whatsapp.com/channel/0029VakUvreFHWpyWUr4Jr0g)
- **Comunidad:** [`Aquí`](https://chat.whatsapp.com/JPwcXvPEUwlEOyjI3BpYys)
- **Contacto(s):** [`Gata Dios`](https://wa.me/message/B3KTM5XN2JMRD1) / [`Russell`](https://api.whatsapp.com/send/?phone=15167096032&text&type=phone_number&app_absent=0) / [`elrebelde21`](https://facebook.com/elrebelde21)
- **Discord:** [`SkyUltraPlus`](https://discord.gg/Ph4eWsZ8)

- [x] **Configuración** <details><summary>**Ajustes del Servidor - GataBot-MD**</summary><img src="https://qu.ax/nHowf.jpg"></details>
----
### 📦⛏️ BOXMINE HOST 
[![YouTube](https://img.shields.io/badge/BoxMine_Host-GataBot-FF0000?style=for-the-badge&logo=youtube&logoColor=white)](https://youtu.be/Ko019wvu2Tc)
[![YouTube](https://img.shields.io/badge/BoxMine_Host-World-FF0000?style=for-the-badge&logo=youtube&logoColor=white)](https://www.youtube.com/@boxminehost)

<a href="https://boxmineworld.com"><img src="https://i.imgur.com/allAyd4.png" height="125px"></a>
### BoxMine World
- **Pagina Oficial:** [`Boxmineworld`](https://boxmineworld.com)
- **Tutorial - Crear cuenta en la Dashboard:** [`Dashboard`](https://www.youtube.com/watch?v=ZAwBLuNmIlI)
- **Dashboard:** [`Dash`](https://dash.boxmineworld.com)
- **Panel:** [`Aquí`](https://panel.boxmineworld.com)
- **Dudas sobre el Host:** [`Discord`](https://discord.gg/84qsr4v) _(Preguntar por Vicemi)_
- **Canal de WhatsApp:** [`Aquí`](https://whatsapp.com/channel/0029Va71C1q2UPBOICnxu83r)

- [x] **Configuración** <details><summary>**Ajustes del Servidor - GataBot-MD**</summary><img src="https://i.imgur.com/tD3NQSR.jpeg"></details>
-----
### 🎇 Hosting Py
<a href="https://dash.hostingpy.shop/"><img src="https://files.catbox.moe/lr92z2.jpg" height="130px"></a>

- **Dashboard:** [`Aquí`](https://dash.hostingpy.shop/)
- **Panel:** [`Aquí`](https://panel.hostingpy.shop/)
- **Registrarse:** [`Aquí`](https://dash.hostingpy.shop/register?ref=GataDios)
- **Canal de WhatsApp:** [`Aquí`](https://whatsapp.com/channel/0029Vak4e1R4NVifmh8Tvi3q)
- **Comunidad:** [`Aquí`](https://chat.whatsapp.com/HT9YFbWTuqO0DQrq6Xxhvx)
- **Contacto:** [`AdrianOficial`](https://wa.me/595976126756)

- [x] **Configuración** <details><summary>**Ajustes del Servidor - GataBot-MD**</summary><img src="https://i.imgur.com/jD7AT0x.png"></details>
-----
### 🚄 DESPLIEGUE
<details>
  <summary><b>Toca para ver más.</b></summary>
  
### ⚡ REPLIT - GATABOT
[![blog](https://img.shields.io/badge/Replit-GataBotMD-FF0000?style=for-the-badge&logo=youtube&logoColor=white)
](https://youtu.be/pQYkq4xv37o)

<a target="_blank" href="https://replit.com/github/GataNina-Li/GataBot-MD"><img alt="Run on Replit" src="https://binbashbanana.github.io/deploy-buttons/buttons/remade/replit.svg"></a> <a href="https://replit.com/github/GataNina-Li/GataBot-MD"> <img src="https://media0.giphy.com/media/lMwu8EJAnv9kmn51KQ/giphy.gif" height="29px"></a>

- [x] Configuración <details><summary>Importar Repositorio - GataBot-MD</summary><img src="https://i.imgur.com/GQyRnMf.jpg"></details>
----
### 🌌 **ACTIVAR EN CODESPACE**

[![Open in GitHub Codespaces](https://github.com/codespaces/badge.svg)](https://github.com/codespaces/new?skip_quickstart=true&machine=basicLinux32gb&repo=GataNina-Li/GataBot-MD&ref=main&geo=UsEast)

----- 
### ⏏️ **ACTIVAR EN KOYEB**
[![Deploy to Koyeb](https://binbashbanana.github.io/deploy-buttons/buttons/remade/koyeb.svg)](https://app.koyeb.com/deploy?type=git&repository=github.com/GataNina-Li/GataBot-MD&branch=master&name=gatabot-md)

------------------
### ☁️ ACTIVAR EN RENDER 
[![Deploy to Render](https://binbashbanana.github.io/deploy-buttons/buttons/remade/render.svg)](https://dashboard.render.com/blueprint/new?repo=https%3A%2F%2Fgithub.com%2FGataNina-Li%2FGataBot-MD)

------------------
## 💻 PARA USUARIOS DE WINDOWS/VPS/RDP

* Descargar e instala Git [`Aquí`](https://git-scm.com/downloads)
* Descargar e instala NodeJS [`Aquí`](https://nodejs.org/en/download)
* Descargar e instala FFmpeg [`Aquí`](https://ffmpeg.org/download.html) (**No olvide agregar FFmpeg a la variable de entorno PATH**)
* Descargar e instala ImageMagick [`Aquí`](https://imagemagick.org/script/download.php)
* Descargar e instala Yarn [`Aquí`](https://classic.yarnpkg.com/en/docs/install#windows-stable)
```bash
git clone https://github.com/GataNina-Li/GataBot-MD && cd GataBot-MD && npm install && npm update && node .
```
## 💻 Instalación de FFmpeg para Windows 
* Descarga cualquiera de las versiones de FFmpeg disponibles haciendo clic en [FFmpeg](https://www.gyan.dev/ffmpeg/builds/).
* Extraer archivos a `C:\` path.
* Cambie el nombre de la carpeta extraída a `ffmpeg`.
* Ejecute el símbolo del sistema como administrador.
* Ejecute el siguiente comando:
```cmd
> setx /m PATH "C:\ffmpeg\bin;%PATH%"
```
Si tiene éxito, le dará un mensaje como: `SUCCESS: specified value was saved`.
* Ahora que tiene FFmpeg instalado, verifique que funcionó ejecutando este comando para ver la versión:
```cmd
> ffmpeg -version
```
</details>

> Recuerda leer la **[Política de GataBot. 😼](https://github.com/GataNina-Li/GataBot-MD/blob/master/terms.md)** antes de hacer algo con este repositorio. 
  
----
### 💠 [`IDIOMAS DISPONIBLES PARA GATABOT`](https://github.com/GataNina-Li/GataBot-MD/blob/master/config.js) 
#### 🌐 Español  
#### 🌐 Inglés (English) 
#### 🌐 Portugués (Português)
#### 🌐 Indonesio (Bahasa Indonesia) 
#### 🌐 Árabe (عرب)
#### 🌐 Hindi (Indian Language)
- [x] Ejemplo <details><summary>Idioma</summary><img src="https://i.imgur.com/ZTwOGkT.jpg"></details>
----

### 🌟 DESARROLLADORES
<a href="https://github.com/GataNina-Li/GataBot-MD/graphs/contributors">
<img src="https://contrib.rocks/image?repo=GataNina-Li/GataBot-MD" /> 
</a>

### 🌟 AGRADECIMIENTOS
[![TheShadowBrokers1](https://github.com/BrunoSobrino.png?size=60)](https://github.com/BrunoSobrino) 

### 🌟 CREADORA 
[![GataNina-Li](https://github.com/GataNina-Li.png?size=100)](https://github.com/GataNina-Li) 
> Copyright (c) 2025 **[GataNina-Li](https://github.com/GataNina-Li/GataBot-MD/blob/master/LICENSE)**.
